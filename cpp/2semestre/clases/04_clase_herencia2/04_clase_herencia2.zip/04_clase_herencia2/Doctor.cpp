#include "Doctor.h"

Doctor::Doctor()
{
    licensesNumber ="no license";
}
