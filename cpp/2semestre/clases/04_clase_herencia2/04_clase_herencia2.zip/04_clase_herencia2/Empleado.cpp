#include "Empleado.h"

Empleado::Empleado()
{
    id_empleado= 0;
    salario = 0;
    position ="no position";
}