#include "Asistente.h"

Asistente::Asistente()
{
}