#include "Asistente.h"
#include "Doctor.h"
#include "Paciente.h"
#include "Persona.h"

int main()
{
    Paciente juan("Juan", 9512039725, "Oaxaca", "sdsda", 9832 );
    Doctor alberto("Alberto", 83193053, "Cdmx", "junii", 742806474, 93275.00, "Doctor", "18348-sdasd");
    return 0;
}
