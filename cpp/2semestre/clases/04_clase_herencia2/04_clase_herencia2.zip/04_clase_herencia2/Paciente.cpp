#include "Paciente.h"

Paciente::Paciente()
{
    id_paciente = 0;
}