#include "Derivada.h"
int main()
{
    Derivada miderivada(3,4);
    miderivada.printValores();
    return 0;
}
