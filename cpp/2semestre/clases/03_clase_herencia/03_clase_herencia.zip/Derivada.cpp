#include "Derivada.h"

Derivada::Derivada()
{
}

void Derivada::printValores()
{
    
    std::cout <<numHer << std::endl;
    std::cout << numeroBaae << std::endl;
}
