
#include "Base.h"
Base::Base(/* args */)
{
}

Base::Base(int nB, int nh)
{
    numeroBaae = nB;
    numHer = nh;
}
