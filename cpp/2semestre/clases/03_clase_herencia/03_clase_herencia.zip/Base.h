#pragma once
class Base
{
private:

public:
    int numeroBaae;
    int numHer;
    Base(/* args */);
    Base(int nB, int nh);
};