#include "Product.h"
#pragma once

class Offer
{
private:
    Product product;
    int discount;

public:
    Offer();
    Offer(Product np, int disc);
    Offer(int disc, Product np );    
    
};