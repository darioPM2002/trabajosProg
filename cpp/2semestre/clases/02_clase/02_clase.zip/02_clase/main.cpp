#include "Product.h"
#include "Offer.h"
int main()
{
    Product cepillo("Cepillo dientes", 50);
    Offer buenFin(cepillo, 30)
    Super walmart();

    return 0;
}
