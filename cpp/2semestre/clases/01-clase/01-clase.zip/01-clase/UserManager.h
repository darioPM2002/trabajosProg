#include "permission.h"
#include "User.h"

#pragma once

class UserManager
{
private:
    
public:
void addUserPermissions (User u, permission p);
};

addUserPermissions (User u, permission p);