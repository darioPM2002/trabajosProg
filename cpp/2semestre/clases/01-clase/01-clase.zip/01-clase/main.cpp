#include "User.h"
int main(int argc, char const *argv[])
{
    User pedro("juan", "juan@tec.mx");
    return 0;
}
