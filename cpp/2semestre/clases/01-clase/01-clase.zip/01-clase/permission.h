#include <string>
using namespace std;
class permission
{
private:
   string name; 
   string description; 
public:
    permission();
    permission(string b,string d);
};

permission::permission(/* args */)
{
    name = "no-value"; 
    description = "no-value"; 
}

permission::permission(string b,string d)
{
    name = b; 
    description = d; 
}
