#include "Circulo.h"

Circulo::Circulo()
{
    radio = 0.0;
    circunferencia = 0.0;
}