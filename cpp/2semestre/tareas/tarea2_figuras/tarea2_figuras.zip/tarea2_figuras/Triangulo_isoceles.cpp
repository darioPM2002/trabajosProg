#include "Triangulo_isoceles.h"

Triangulo_isoceles::Triangulo_isoceles()
{
}