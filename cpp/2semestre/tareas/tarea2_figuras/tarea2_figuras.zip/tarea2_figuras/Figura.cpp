#include "Figura.h"

Figura::Figura()
{
nombbre= "no name";
}

Figura::Figura(std::string n, int l)
{   
    lados = l;
    nombbre = n;
}
