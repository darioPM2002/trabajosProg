#include "Prisma_rec.h"

Prisma::Prisma()
{
}