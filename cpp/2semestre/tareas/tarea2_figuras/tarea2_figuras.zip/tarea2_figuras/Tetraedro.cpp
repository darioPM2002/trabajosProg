#include "Tetraedro.h"

Tetraedro::Tetraedro()
{
}