#include "Cono.h"

Cono::Cono()
{
}