#include "Cuadrado.h"

Cuadrado::Cuadrado()
{
    lonLado = 0;
}