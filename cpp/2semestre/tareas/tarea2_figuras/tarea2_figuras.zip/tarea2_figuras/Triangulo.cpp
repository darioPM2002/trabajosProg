#include "Triangulo.h"

Triangulo::Triangulo()
{
    base = 0;
    altura = 0;
}