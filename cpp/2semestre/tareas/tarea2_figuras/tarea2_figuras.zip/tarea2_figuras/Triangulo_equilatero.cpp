#include "Triangulo_equilatero.h"

Triangulo_equilatero::Triangulo_equilatero()
{
}