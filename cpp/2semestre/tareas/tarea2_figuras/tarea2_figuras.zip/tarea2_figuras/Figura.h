#include <iostream>
#pragma once

class Figura
{
protected:
    std::string nombbre;
    int lados;
public:
    Figura(/* args */);
    Figura(std::string n, int l);
};


