#include "Triangulo_derecho.h"

Triangulo_derecho::Triangulo_derecho()
{
}