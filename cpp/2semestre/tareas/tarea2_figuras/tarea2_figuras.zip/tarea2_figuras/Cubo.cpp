#include "Cubo.h"

Cubo::Cubo()
{
}