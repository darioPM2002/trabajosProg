#include "GeoFigura3d.h"

GeoFigura3d::GeoFigura3d()
{
    volumen = 0.0;
    caras = 0;

}