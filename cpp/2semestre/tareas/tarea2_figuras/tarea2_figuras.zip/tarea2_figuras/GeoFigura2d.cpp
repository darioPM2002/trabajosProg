#include "GeoFigura2d.h"

GeoFigura2d::GeoFigura2d()
{
    altura = 0.0;
    base   = 0.0;
}