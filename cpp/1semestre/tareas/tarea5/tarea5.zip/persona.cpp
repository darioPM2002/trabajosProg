#include "persona.h"

persona::persona(){

birthDate= Date();
first_name="No name";

last_name="No name";
};
persona::persona(Date birthDate, string first_name, string last_name){

birthDate= birthDate;
first_name=first_name;

last_name=last_name;
};
