
class impuestosClass
{

public:
    void calcularIva(double cantidad);
    void calcularIsr(double cantidad);
};

