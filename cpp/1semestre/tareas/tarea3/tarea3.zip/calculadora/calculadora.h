#include <iostream>

class Calculadora 
{
public:
  int suma(int a, int b);
  
  int resta(int a, int b);
  
  double division(double a, double b);
  
  int multiplicacion(int a, int b);
  
  int max(int a, int b);
  
  int menor(int a, int b);
};